package com.usa.ri.gov.ies.admin.model;

import java.util.Date;

import lombok.Data;

@Data
public class Plan {

	private Integer planId;

	private String planName;

	private String planDesc;

	private Date startate;

	private Date endDate;

	private String activeSw;

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getPlanDesc() {
		return planDesc;
	}

	public void setPlanDesc(String planDesc) {
		this.planDesc = planDesc;
	}

	public Date getStartate() {
		return startate;
	}

	public void setStartate(Date startate) {
		this.startate = startate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getActiveSw() {
		return activeSw;
	}

	public void setActiveSw(String activeSw) {
		this.activeSw = activeSw;
	}
	
	
	

}
