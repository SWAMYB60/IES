package com.usa.ri.gov.ies.admin.service;

import java.util.List;

import com.usa.ri.gov.ies.admin.model.AppAccount;
import com.usa.ri.gov.ies.admin.model.Plan;

public interface AdminService {

	public boolean registerAccount(AppAccount appAccount);
	
	public boolean registerPlan(Plan plan);

	public String findByEmail(String emailId);
	 
	
	public List<AppAccount> findAllAppAccounts();
	
	public List<Plan> findAllPlans();
	
	public boolean updateAccountSw(String accId,String activeSw);
	
	public boolean updatePlanSw(String planId,String activeSw);
}
