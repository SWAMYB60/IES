package com.usa.ri.gov.ies.admin.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.usa.ri.gov.ies.admin.entity.PlanEntity;

@Repository("planRepository")
public interface PlanRepository extends JpaRepository<PlanEntity, Serializable> {

	/*@Query(name = "from PlanEntity where planname=:planId")
	public PlanEntity findByPlan(String planId);*/
	
}
